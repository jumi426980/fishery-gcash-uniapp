const t=""+new URL("top-4e027935.jpg",import.meta.url).href;export{t};
