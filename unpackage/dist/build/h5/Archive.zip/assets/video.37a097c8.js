const e=""+new URL("video-a9b9169e.jpg",import.meta.url).href;export{e as v};
